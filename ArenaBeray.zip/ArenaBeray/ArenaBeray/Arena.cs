﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArenaBeray
{
    public class Arena
    {
        public List<Hero> Heroes { get; private set; }

        public GameEventListener EventListener { get; set; }

        public Arena(params Hero[] heroes)
        {
            Heroes = heroes.ToList();
        }

        public Hero Battle()
        {
            while (Heroes.Count(h => h.IsAlive) > 1)
            {
                for (int i = 0; i < Heroes.Count; i++)
                {
                    if (!Heroes[i].IsAlive)
                    {
                        continue;
                    }

                    Hero attacker = Heroes[i];
                    Hero defender = GetRandomDefender(attacker);

                    if (defender == null)
                    {
                        break;
                    }

                    int damage = attacker.Attack();
                    defender.TakeDamage(damage);

                    if (EventListener != null)
                    {
                        EventListener.GameRound(attacker, defender, damage);
                    }

                    if (defender.IsDead)
                    {
                        Console.WriteLine($"{defender.Name} has been eliminated!");
                    }
                }
            }

            Hero winner = Heroes.FirstOrDefault(h => h.IsAlive);
            return winner;
        }

        private Hero GetRandomDefender(Hero attacker)
        {
            List<Hero> possibleDefenders = Heroes.Where(h => h.IsAlive && h != attacker).ToList();
            if (possibleDefenders.Count == 0)
            {
                return null;
            }
            Random random = new Random();
            int index = random.Next(possibleDefenders.Count);
            return possibleDefenders[index];
        }
    }
}
