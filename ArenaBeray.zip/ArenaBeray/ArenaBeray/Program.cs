﻿using ArenaBeray;

namespace ArenaBeray
{
    class ConsoleGameEventListener : GameEventListener
    {
        public override void GameRound(Hero attacker, Hero defender, int attack)
        {
            string message = $"{attacker.Name} attacked {defender.Name} for {attack} points";
            if (defender.IsAlive)
            {
                message = message + $" but {defender.Name} survived.";
            }
            else
            {
                message = message + $" and {defender.Name} died.";
            }
            Console.WriteLine(message);
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Knight knight = new Knight("Sir John");
            Rogue rogue = new Rogue("Slim Shady");
            BerFire berFire = new BerFire("BerFire");
            Devin devin = new Devin("Devin");

            Arena arena = new Arena(knight, rogue, berFire, devin);
            arena.EventListener = new ConsoleGameEventListener();

            Console.WriteLine("Let the epic showdown commence!");
            Hero winner = arena.Battle();
            Console.WriteLine($"The dust settles... and the champion is: {winner.Name}!");
            Console.ReadLine();
        }
    }
}
