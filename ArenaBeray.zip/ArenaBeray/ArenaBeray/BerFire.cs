﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;
namespace ArenaBeray
{
//    BerFire is a mage with fire abilities.
//    Fire Shield: Has a 20% chance to deflect 50% of the damage taken back to the attacker.
//    Fireball: Has a 25% chance to deal an additional 50% damage with each hit.
    public class BerFire : Hero
    {
        public BerFire(string name) : base(name)
        {
        }

        public override void TakeDamage(int incomingDamage)
        {
            int dice = Random.Shared.Next(0, 100);
            if (dice < 20)
            {
                int reflectedDamage = (incomingDamage * 50) / 100;
                base.TakeDamage(incomingDamage - reflectedDamage);
              
            }
            else
            {
                base.TakeDamage(incomingDamage);
            }
        }

        public override int Attack()
        {
            int baseAttack = base.Attack();
            int dice = Random.Shared.Next(0, 100);
            if (dice < 25)
            {
                baseAttack += (baseAttack * 50) / 100;
            }
            return baseAttack;
        }
    }
}
