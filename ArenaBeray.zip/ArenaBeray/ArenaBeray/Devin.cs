﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace ArenaBeray
{
//    Devin is a hunter skilled in archery and camouflage.
//    Stealth: Has a 40% chance to completely avoid damage.
//    Precision Strike: Has a 20% chance to deal double damage on attack.
    public class Devin : Hero
    {
        public Devin(string name) : base(name)
        {
        }

        public override void TakeDamage(int incomingDamage)
        {
            int dice = Random.Shared.Next(0, 100);
            if (dice < 40)
            {
                incomingDamage = 0;
            }
            base.TakeDamage(incomingDamage);
        }

        public override int Attack()
        {
            int baseAttack = base.Attack();
            int dice = Random.Shared.Next(0, 100);
            if (dice < 20)
            {
                baseAttack *= 2;
            }
            return baseAttack;
        }
    }
}
